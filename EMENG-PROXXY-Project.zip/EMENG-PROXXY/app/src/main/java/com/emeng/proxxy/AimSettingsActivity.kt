package com.emeng.proxxy

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class AimSettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(24,24,24,24); setBackgroundColor(Color.rgb(8,10,18)) }
        root.addView(TextView(this).apply { text = "AIM SETTINGS"; textSize = 24f; setTextColor(Color.CYAN) })
        listOf("AIMLOCK HEAD", "AIMLOCK BADAN", "AIM TO HEADSHOT").forEach { label -> root.addView(CheckBox(this).apply { text = label; setTextColor(Color.WHITE) }) }
        root.addView(TextView(this).apply { text = "DRAG SENSI"; setTextColor(Color.WHITE); setPadding(0,20,0,0) })
        val slider = SeekBar(this).apply { max = 99; progress = PreferencesManager(this@AimSettingsActivity).getSensitivity() - 1 }
        root.addView(slider)
        root.addView(Button(this).apply { text = "SIMPAN"; setOnClickListener { PreferencesManager(this@AimSettingsActivity).setSensitivity(slider.progress + 1); finish() } })
        root.addView(TextView(this).apply { text = "Pengaturan lokal; tidak mengendalikan bidikan di game."; setTextColor(Color.LTGRAY) })
        setContentView(root)
    }
}
