package com.emeng.proxxy

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(24,24,24,24); setBackgroundColor(Color.rgb(8,10,18)) }
        root.addView(TextView(this).apply { text = "SETTINGS"; textSize = 24f; setTextColor(Color.CYAN) })
        root.addView(Button(this).apply { text = "STOP OVERLAY"; setOnClickListener { OverlayController.stop(this@SettingsActivity); Toast.makeText(this@SettingsActivity, "Overlay dihentikan", Toast.LENGTH_SHORT).show() } })
        root.addView(Button(this).apply { text = "LOGOUT"; setOnClickListener { PreferencesManager(this@SettingsActivity).setLoggedIn(false); OverlayController.stop(this@SettingsActivity); startActivity(Intent(this@SettingsActivity, LoginActivity::class.java)); finish() } })
        setContentView(root)
    }
}
