package com.emeng.proxxy

import android.content.Context
import android.content.Intent
import android.provider.Settings

object OverlayController {
    fun start(context: Context): Boolean {
        if (!Settings.canDrawOverlays(context)) return false
        context.startService(Intent(context, OverlayService::class.java))
        return true
    }
    fun stop(context: Context) { context.stopService(Intent(context, OverlayService::class.java)) }
}
