package com.emeng.proxxy

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class EspMenuActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(24,24,24,24); setBackgroundColor(Color.rgb(8,10,18)) }
        root.addView(TextView(this).apply { text = "ESP MENU"; textSize = 24f; setTextColor(Color.CYAN) })
        listOf("ESP LINE", "ESP BOX", "ESP NAME", "ESP BAR").forEach { label -> root.addView(CheckBox(this).apply { text = label; setTextColor(Color.WHITE) }) }
        root.addView(TextView(this).apply { text = "Menu konfigurasi UI. Tidak membaca posisi tersembunyi dalam Free Fire."; setTextColor(Color.LTGRAY); setPadding(0,18,0,0) })
        setContentView(root)
    }
}
