package com.emeng.proxxy

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MacroSettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(24,24,24,24); setBackgroundColor(Color.rgb(8,10,18)) }
        root.addView(TextView(this).apply { text = "MACRO SETTINGS"; textSize = 24f; setTextColor(Color.CYAN) })
        root.addView(TextView(this).apply { text = "Pengaturan macro untuk aktivitas aplikasi sendiri."; setTextColor(Color.LTGRAY) })
        root.addView(Button(this).apply { text = "START"; setOnClickListener { Toast.makeText(this@MacroSettingsActivity, "Macro lokal siap", Toast.LENGTH_SHORT).show() } })
        root.addView(Button(this).apply { text = "STOP"; setOnClickListener { Toast.makeText(this@MacroSettingsActivity, "Dihentikan", Toast.LENGTH_SHORT).show() } })
        setContentView(root)
    }
}
