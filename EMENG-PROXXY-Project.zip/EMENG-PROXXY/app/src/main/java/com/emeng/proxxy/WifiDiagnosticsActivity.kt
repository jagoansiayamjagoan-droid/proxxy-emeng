package com.emeng.proxxy

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.content.Context
import android.net.ConnectivityManager

class WifiDiagnosticsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(24,24,24,24); setBackgroundColor(Color.rgb(8,10,18)) }
        root.addView(TextView(this).apply { text = "WI-FI DIAGNOSTICS"; textSize = 22f; setTextColor(Color.CYAN) })
        val status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f }
        root.addView(status)
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        status.text = if (cm.activeNetwork != null) "Status: perangkat memiliki jaringan aktif." else "Status: tidak ada jaringan aktif."
        root.addView(Button(this).apply { text = "FREEZE (LOCAL UI)"; setOnClickListener { Toast.makeText(this@WifiDiagnosticsActivity, "Hanya simulasi lokal; jaringan tidak diubah", Toast.LENGTH_LONG).show() } })
        root.addView(Button(this).apply { text = "GHOST (STATUS)"; setOnClickListener { Toast.makeText(this@WifiDiagnosticsActivity, status.text, Toast.LENGTH_SHORT).show() } })
        setContentView(root)
    }
}
