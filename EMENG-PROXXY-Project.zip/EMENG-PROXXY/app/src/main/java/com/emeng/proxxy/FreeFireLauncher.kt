package com.emeng.proxxy

import android.content.Context
import android.content.Intent

object FreeFireLauncher {
    private const val GAME_PACKAGE = "com.dts.freefireth"
    fun launch(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(GAME_PACKAGE) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { context.startActivity(intent); true } catch (_: Exception) { false }
    }
}
