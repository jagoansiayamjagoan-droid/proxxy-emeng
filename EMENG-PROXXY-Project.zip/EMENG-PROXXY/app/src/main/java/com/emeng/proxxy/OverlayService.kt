package com.emeng.proxxy

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var panel: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (panel != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.rgb(12, 17, 30))
        }
        root.addView(TextView(this).apply { text = "EP • EMENG PROXXY"; textSize = 16f; setTextColor(Color.CYAN); setPadding(4, 4, 4, 8) })
        fun add(label: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        add("ENTER — FREE FIRE") {
            if (!FreeFireLauncher.launch(this)) Toast.makeText(this, "Free Fire tidak ditemukan", Toast.LENGTH_LONG).show()
        }
        add("AIM SETTINGS") { openScreen(AimSettingsActivity::class.java) }
        add("ESP MENU") { openScreen(EspMenuActivity::class.java) }
        add("MACRO") { openScreen(MacroSettingsActivity::class.java) }
        add("WI-FI") { openScreen(WifiDiagnosticsActivity::class.java) }
        add("MINIMIZE") { root.visibility = View.GONE; showBubble(root) }
        add("CLOSE") { stopSelf() }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 120 }
        root.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = params ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; return true }
                    MotionEvent.ACTION_MOVE -> { p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt(); wm?.updateViewLayout(root, p); return true }
                }
                return false
            }
        })
        panel = root
        try { wm?.addView(root, params) } catch (_: Exception) { panel = null; stopSelf() }
        return START_NOT_STICKY
    }

    private fun showBubble(root: LinearLayout) {
        root.visibility = View.VISIBLE
        root.removeAllViews()
        root.addView(Button(this).apply {
            text = "EP  •  OPEN"
            setOnClickListener {
                root.removeAllViews()
                root.addView(TextView(this@OverlayService).apply { text = "EMENG PROXXY"; setTextColor(Color.CYAN) })
                root.addView(Button(this@OverlayService).apply { text = "ENTER — FREE FIRE"; setOnClickListener { if (!FreeFireLauncher.launch(this@OverlayService)) Toast.makeText(this@OverlayService, "Free Fire tidak ditemukan", Toast.LENGTH_SHORT).show() } })
                root.addView(Button(this@OverlayService).apply { text = "CLOSE"; setOnClickListener { stopSelf() } })
            }
        })
    }

    private fun openScreen(cls: Class<*>) {
        startActivity(Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onDestroy() {
        try { if (panel != null) wm?.removeView(panel) } catch (_: Exception) {}
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
