package com.emeng.proxxy

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class DashboardActivity : Activity() {
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(22, 24, 22, 24); setBackgroundColor(Color.rgb(8,10,18)) }
        root.addView(TextView(this).apply { text = "EMENG PROXXY"; textSize = 27f; setTextColor(Color.CYAN); gravity = Gravity.CENTER; setPadding(0, 10, 0, 22) })
        root.addView(button("ENTER — BUKA FREE FIRE") {
            if (!FreeFireLauncher.launch(this)) Toast.makeText(this, "Free Fire com.dts.freefireth tidak ditemukan", Toast.LENGTH_LONG).show()
        })
        root.addView(button("OPEN FLOATING PANEL") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Overlay diminta aktif", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(button("AIM SETTINGS") { startActivity(Intent(this, AimSettingsActivity::class.java)) })
        root.addView(button("ESP MENU") { startActivity(Intent(this, EspMenuActivity::class.java)) })
        root.addView(button("MACRO") { startActivity(Intent(this, MacroSettingsActivity::class.java)) })
        root.addView(button("WI-FI DIAGNOSTICS") { startActivity(Intent(this, WifiDiagnosticsActivity::class.java)) })
        root.addView(button("SETTINGS") { startActivity(Intent(this, SettingsActivity::class.java)) })
        root.addView(button("LOGOUT") { PreferencesManager(this).setLoggedIn(false); stopService(Intent(this, OverlayService::class.java)); startActivity(Intent(this, LoginActivity::class.java)); finish() })
        setContentView(root)
    }
}
