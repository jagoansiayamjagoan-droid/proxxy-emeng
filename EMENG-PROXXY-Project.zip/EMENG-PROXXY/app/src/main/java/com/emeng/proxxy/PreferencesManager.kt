package com.emeng.proxxy

import android.content.Context

class PreferencesManager(context: Context) {
    private val prefs = context.getSharedPreferences("emeng_proxxy", Context.MODE_PRIVATE)
    fun isLoggedIn() = prefs.getBoolean("logged_in", false)
    fun setLoggedIn(value: Boolean) { prefs.edit().putBoolean("logged_in", value).apply() }
    fun getSensitivity() = prefs.getInt("sensitivity", 50)
    fun setSensitivity(value: Int) { prefs.edit().putInt("sensitivity", value.coerceIn(1, 100)).apply() }
}
