package com.emeng.proxxy

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = PreferencesManager(this)
        startActivity(Intent(this, if (prefs.isLoggedIn()) DashboardActivity::class.java else LoginActivity::class.java))
        finish()
    }
}
