package com.emeng.proxxy

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class LoginActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32); setBackgroundColor(Color.rgb(8, 10, 18))
        }
        root.addView(TextView(this).apply { text = "EP  •  EMENG PROXXY"; textSize = 26f; setTextColor(Color.CYAN); gravity = Gravity.CENTER })
        root.addView(TextView(this).apply { text = "LOGIN"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 22, 0, 18) })
        val user = EditText(this).apply { hint = "Username"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        val pass = EditText(this).apply { hint = "Password"; setSingleLine(); inputType = 129; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        root.addView(user, LinearLayout.LayoutParams(-1, -2))
        root.addView(pass, LinearLayout.LayoutParams(-1, -2))
        val login = Button(this).apply { text = "LOGIN" }
        root.addView(login, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 20 })
        login.setOnClickListener {
            if (CredentialValidator.isValid(user.text.toString().trim(), pass.text.toString())) {
                PreferencesManager(this).setLoggedIn(true)
                startActivity(android.content.Intent(this, DashboardActivity::class.java)); finish()
            } else Toast.makeText(this, "Username atau password salah", Toast.LENGTH_SHORT).show()
        }
        setContentView(root)
    }
}
