package com.emeng.proxxy

object CredentialValidator {
    // Demo credentials only. Static credentials can be extracted from an APK.
    fun isValid(username: String, password: String): Boolean =
        username == "emeng" && password == "proxxy"
}
