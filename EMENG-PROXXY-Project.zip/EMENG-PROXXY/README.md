# EMENG PROXXY

Proyek Android native Kotlin dengan login lokal, dashboard, floating overlay, dan tombol ENTER untuk mencoba membuka package `com.dts.freefireth`.

## Login demo
- Username: `emeng`
- Password: `proxxy`

Kredensial statis ini hanya untuk prototipe; dapat ditemukan melalui reverse engineering APK. Jangan gunakan untuk melindungi data sensitif.

## Build lewat GitHub Actions
1. Unggah folder proyek ke repositori GitHub.
2. Pastikan branch utama bernama `main`.
3. Buka tab **Actions**.
4. Jalankan workflow **Android Build** atau push perubahan ke `main`.
5. Setelah selesai, unduh artifact **EMENG-PROXXY-APK**.

Workflow menghasilkan `EMENG-PROXXY.apk`.

## Build lokal
Proyek menggunakan Gradle Kotlin DSL, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, JDK 17, dan Android SDK 35. Buka folder proyek melalui AndroidIDE yang mendukung konfigurasi tersebut, lalu jalankan tugas `assembleDebug`.

## Izin overlay
Di dashboard, tekan **OPEN FLOATING PANEL**. Jika diminta, izinkan EMENG PROXXY tampil di atas aplikasi lain melalui Pengaturan Android, lalu kembali ke aplikasi dan tekan tombol tersebut lagi.

## ENTER
Tombol ENTER mencoba meluncurkan `com.dts.freefireth`. Jika paket itu tidak tersedia, aplikasi menampilkan pesan bahwa game tidak ditemukan.

## Batasan
Overlay adalah panel Android. Izin overlay tidak memberikan akses ke memori game, posisi pemain tersembunyi, atau kendali bidikan Free Fire. Menu aim/ESP merupakan pengaturan UI lokal; macro tidak mengirim input ke game eksternal. FREEZE/GHOST hanya diagnostik lokal dan tidak memutus koneksi pemain lain.

## Catatan Android
Versi Android dan kebijakan perangkat dapat membatasi service latar belakang atau overlay. Jika panel tidak muncul, periksa izin overlay dan pengaturan baterai perangkat.
